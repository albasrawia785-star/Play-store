/**
 * نظام التحقق بخطوتين (2FA) عبر سؤال الأمان المخصص للمدراء
 * يوفر تشفيراً متناظراً (AES-256-GCM) للإجابات قبل تخزينها في قاعدة البيانات،
 * مع إمكانية فك التشفير حصراً للإدارة العامة عند نسيان المدير لإجابته.
 */

export interface SecurityQuestionOption {
  id: string;
  label: string;
}

export const CUSTOM_QUESTION_ID = '__custom__';

export const PRESET_SECURITY_QUESTIONS: SecurityQuestionOption[] = [
  {
    id: CUSTOM_QUESTION_ID,
    label: 'سؤال مخصص (أكتبه بنفسي)',
  },
  {
    id: 'secret_code',
    label: 'ما هو كود أو كلمة الأمان السرية الخاصة بك؟',
  },
  {
    id: 'first_school',
    label: 'ما اسم أول مدرسة درست فيها؟',
  },
  {
    id: 'childhood_friend',
    label: 'ما اسم صديق الطفولة المقرب؟',
  },
  {
    id: 'birth_city',
    label: 'ما اسم المدينة أو المنطقة التي ولدت فيها؟',
  },
  {
    id: 'mother_grandpa',
    label: 'ما اسم والدتك أو جدك؟',
  },
];

// بذور المفتاح السري لتشفير إجابات التحقق بخطوتين (AES-256-GCM)
const _2FA_KEY_BYTES: number[] = [
  0x41, 0x6c, 0x64, 0x69, 0x6f, 0x6e, 0x32, 0x46,
  0x41, 0x5f, 0x53, 0x65, 0x63, 0x75, 0x72, 0x65,
  0x56, 0x61, 0x75, 0x6c, 0x74, 0x5f, 0x32, 0x30,
  0x32, 0x36, 0x5f, 0x4b, 0x65, 0x79, 0x21, 0x23,
];

function getMasterKeyBytes(): Uint8Array {
  return new Uint8Array(_2FA_KEY_BYTES);
}

function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function hexToBytes(hex: string): Uint8Array {
  const clean = hex.trim();
  const len = Math.floor(clean.length / 2);
  const out = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    out[i] = parseInt(clean.substring(i * 2, i * 2 + 2), 16) || 0;
  }
  return out;
}

/**
 * توحيد وتطبيع نص الإجابة عند المقارنة (تجاهل الهمزات، التاء المربوطة، التشكيل، والمسافات الزائدة، وتوحيد الأرقام)
 */
export function normalizeSecurityAnswer(input: string): string {
  if (!input) return '';
  return String(input)
    .trim()
    .replace(/\s+/g, ' ')
    // إزالة التشكيل العربي
    .replace(/[\u064B-\u065F\u0670]/g, '')
    // توحيد الألف
    .replace(/[أإآٱ]/g, 'ا')
    // توحيد التاء المربوطة والهاء
    .replace(/ة/g, 'ه')
    // توحيد الألف المقصورة والياء
    .replace(/ى/g, 'ي')
    // تحويل الأرقام الهندية والفارسية إلى إنجليزية
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .toLowerCase();
}

/**
 * تشفير احتياطي متناظر خفيف في حال عدم توفر WebCrypto (مثل بيئات WebView غير HTTPS)
 */
function fallbackStreamEncrypt(plainText: string): string {
  const encoder = new TextEncoder();
  const data = encoder.encode(plainText);
  const key = getMasterKeyBytes();
  const salt = new Uint8Array(8);
  for (let i = 0; i < 8; i++) {
    salt[i] = Math.floor(Math.random() * 256);
  }
  const encrypted = new Uint8Array(data.length);
  for (let i = 0; i < data.length; i++) {
    const kByte = key[i % key.length] ^ salt[i % salt.length] ^ ((i * 31) & 0xff);
    encrypted[i] = data[i] ^ kByte;
  }
  return `enc2fa:v2:${bytesToHex(salt)}:${bytesToHex(encrypted)}`;
}

function fallbackStreamDecrypt(payload: string): string {
  const parts = payload.split(':');
  if (parts.length !== 4) return '';
  const salt = hexToBytes(parts[2]);
  const encrypted = hexToBytes(parts[3]);
  const key = getMasterKeyBytes();
  const decrypted = new Uint8Array(encrypted.length);
  for (let i = 0; i < encrypted.length; i++) {
    const kByte = key[i % key.length] ^ salt[i % salt.length] ^ ((i * 31) & 0xff);
    decrypted[i] = encrypted[i] ^ kByte;
  }
  const decoder = new TextDecoder();
  return decoder.decode(decrypted);
}

/**
 * تشفير إجابة سؤال الأمان باستخدام AES-256-GCM قبل الحفظ في قاعدة البيانات
 */
export async function encrypt2FAAnswer(plainText: string): Promise<string> {
  const trimmed = String(plainText || '').trim();
  if (!trimmed) return '';

  try {
    if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
      const keyBytes = getMasterKeyBytes();
      const iv = window.crypto.getRandomValues(new Uint8Array(12));
      const cryptoKey = await window.crypto.subtle.importKey(
        'raw',
        keyBytes.buffer as ArrayBuffer,
        { name: 'AES-GCM' },
        false,
        ['encrypt']
      );
      const encoded = new TextEncoder().encode(trimmed);
      const cipherBuffer = await window.crypto.subtle.encrypt(
        { name: 'AES-GCM', iv },
        cryptoKey,
        encoded
      );
      const cipherBytes = new Uint8Array(cipherBuffer);
      return `enc2fa:v1:${bytesToHex(iv)}:${bytesToHex(cipherBytes)}`;
    }
  } catch {
    // fallback below
  }

  return fallbackStreamEncrypt(trimmed);
}

/**
 * فك تشفير إجابة سؤال الأمان (تُستخدم أثناء التحقق عند الدخول ولدى الإدارة العامة عند النسيان)
 */
export async function decrypt2FAAnswer(encryptedValue: string | null | undefined): Promise<string> {
  if (!encryptedValue) return '';
  const raw = String(encryptedValue).trim();
  if (!raw) return '';

  if (raw.startsWith('enc2fa:v1:')) {
    try {
      const parts = raw.split(':');
      if (parts.length === 4 && typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
        const iv = hexToBytes(parts[2]);
        const cipherBytes = hexToBytes(parts[3]);
        const keyBytes = getMasterKeyBytes();
        const cryptoKey = await window.crypto.subtle.importKey(
          'raw',
          keyBytes.buffer as ArrayBuffer,
          { name: 'AES-GCM' },
          false,
          ['decrypt']
        );
        const plainBuffer = await window.crypto.subtle.decrypt(
          { name: 'AES-GCM', iv: iv.buffer as ArrayBuffer },
          cryptoKey,
          cipherBytes.buffer as ArrayBuffer
        );
        return new TextDecoder().decode(plainBuffer);
      }
    } catch {
      return '';
    }
  }

  if (raw.startsWith('enc2fa:v2:')) {
    try {
      return fallbackStreamDecrypt(raw);
    } catch {
      return '';
    }
  }

  // نص غير مشفر قديم (التوافق العكسي)
  return raw;
}

/**
 * التحقق من تطابق الإجابة المدخلة مع الإجابة المشفرة المخزنة
 */
export async function verify2FAAnswer(
  enteredAnswer: string,
  encryptedStoredAnswer: string | null | undefined
): Promise<boolean> {
  if (!enteredAnswer || !encryptedStoredAnswer) return false;
  const decrypted = await decrypt2FAAnswer(encryptedStoredAnswer);
  if (!decrypted) return false;
  return normalizeSecurityAnswer(enteredAnswer) === normalizeSecurityAnswer(decrypted);
}
