export interface DeletionEvent {
  id: string;
  entityType: 'debtor' | 'creditor' | 'installment' | 'supplier' | 'transaction';
  entityName: string;
  details?: string;
  amount?: number;
  deletedAt: string;
  timestamp: number;
  extraInfo?: string;
  snapshotData?: any;
}

const LEGACY_STORAGE_KEY = 'local_deletions_log';
const STORAGE_KEY_PREFIX = 'local_deletions_log_user_';
const MAX_DELETIONS_LOG_SIZE = 100;

export const DELETIONS_UPDATED_EVENT = 'deletions_log_updated';

function resolveDeletionStorageKey(explicitUserId?: number): string | null {
  try {
    let targetId = explicitUserId && explicitUserId > 0 ? explicitUserId : 0;
    if (!targetId) {
      const rawSession = localStorage.getItem('session_user');
      if (rawSession) {
        const parsed = JSON.parse(rawSession);
        if (parsed && parsed.id) {
          targetId =
            parsed.role === 'supervisor' && parsed.parentManagerId
              ? Number(parsed.parentManagerId)
              : Number(parsed.id);
        }
      }
    }

    if (!targetId || isNaN(targetId)) {
      return null;
    }

    const userKey = `${STORAGE_KEY_PREFIX}${targetId}`;

    // One-time safe migration of legacy key to current active user, then remove global key permanently
    const legacyRaw = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (legacyRaw !== null) {
      if (localStorage.getItem(userKey) === null) {
        localStorage.setItem(userKey, legacyRaw);
      }
      localStorage.removeItem(LEGACY_STORAGE_KEY);
    }

    return userKey;
  } catch {
    return null;
  }
}

export const getDeletionEvents = (userId?: number): DeletionEvent[] => {
  try {
    const key = resolveDeletionStorageKey(userId);
    if (!key) return [];
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Failed to load deletion logs:', err);
    return [];
  }
};

export const saveDeletionEvents = (events: DeletionEvent[], userId?: number): void => {
  try {
    const key = resolveDeletionStorageKey(userId);
    if (!key) return;
    localStorage.setItem(key, JSON.stringify(events.slice(0, MAX_DELETIONS_LOG_SIZE)));
    window.dispatchEvent(new CustomEvent(DELETIONS_UPDATED_EVENT));
  } catch (err) {
    console.error('Failed to save deletion logs:', err);
  }
};

export const logDeletionEvent = (
  event: Omit<DeletionEvent, 'id' | 'deletedAt' | 'timestamp'>,
  userId?: number
): DeletionEvent | null => {
  try {
    const key = resolveDeletionStorageKey(userId);
    if (!key) return null;

    const now = new Date();
    const newEvent: DeletionEvent = {
      ...event,
      id: `del_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      deletedAt: now.toISOString(),
      timestamp: now.getTime(),
    };

    const existing = getDeletionEvents(userId);
    const updated = [newEvent, ...existing].slice(0, MAX_DELETIONS_LOG_SIZE);
    localStorage.setItem(key, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent(DELETIONS_UPDATED_EVENT));
    return newEvent;
  } catch (err) {
    console.error('Failed to log deletion event:', err);
    return null;
  }
};

export const removeDeletionEvent = (id: string, userId?: number): void => {
  try {
    const key = resolveDeletionStorageKey(userId);
    if (!key) return;
    const existing = getDeletionEvents(userId);
    const updated = existing.filter((e) => e.id !== id);
    localStorage.setItem(key, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent(DELETIONS_UPDATED_EVENT));
  } catch (err) {
    console.error('Failed to remove deletion log:', err);
  }
};

export const clearDeletionEvents = (userId?: number): void => {
  try {
    const key = resolveDeletionStorageKey(userId);
    if (key) {
      localStorage.removeItem(key);
    }
    localStorage.removeItem(LEGACY_STORAGE_KEY);
    window.dispatchEvent(new CustomEvent(DELETIONS_UPDATED_EVENT));
  } catch (err) {
    console.error('Failed to clear deletion logs:', err);
  }
};


