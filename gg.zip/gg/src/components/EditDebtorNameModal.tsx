import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Debtor } from '../types';
import { useI18n } from '../i18n/index.tsx';
import { formatNumber } from '../utils/formatters';
import { checkNameDuplicate, ExistingNameRecord } from '../utils/nameDuplicateChecker';
import { NameDuplicateAlert } from './NameDuplicateAlert';

interface EditDebtorNameModalProps {
  isOpen: boolean;
  debtor: Debtor | null;
  requireCustomerPhone?: boolean;
  onClose: () => void;
  onSave: (debtorId: number, newName: string, newPhone?: string) => Promise<void> | void;
  existingDebtors?: Debtor[];
}

export const EditDebtorNameModal: React.FC<EditDebtorNameModalProps> = ({
  isOpen,
  debtor,
  requireCustomerPhone = false,
  onClose,
  onSave,
  existingDebtors = [],
}) => {
  const { t, currency } = useI18n();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [allowDuplicateName, setAllowDuplicateName] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen && debtor) {
      setName(debtor.name || '');
      setPhone(debtor.phone || '');
      setError(null);
      setAllowDuplicateName(false);
      setIsSubmitting(false);
      // Auto-focus the input after modal renders
      setTimeout(() => {
        if (inputRef.current) {
          inputRef.current.focus();
          inputRef.current.select();
        }
      }, 60);
    }
  }, [isOpen, debtor]);

  const candidateRecords: ExistingNameRecord[] = useMemo(() => {
    if (!existingDebtors || !debtor) return [];
    return existingDebtors
      .filter((d) => d.id !== debtor.id && (d.type || 'debtor') === (debtor.type || 'debtor'))
      .map((d) => ({
        id: d.id,
        name: d.name,
        phone: d.phone,
        amount: d.amount,
        type: d.type || 'debtor',
      }));
  }, [existingDebtors, debtor]);

  const nameCheckResult = useMemo(() => {
    if (!debtor) return { hasExactMatch: false, hasSimilarMatches: false, similarMatches: [] };
    return checkNameDuplicate(name, candidateRecords, debtor.id);
  }, [name, candidateRecords, debtor]);

  if (!isOpen || !debtor) return null;

  const currentTrimmedName = debtor.name?.trim() || '';
  const currentTrimmedPhone = debtor.phone?.trim() || '';
  const initialLetter = currentTrimmedName ? currentTrimmedName.charAt(0) : '?';
  const trimmedName = name.trim();
  const trimmedPhone = phone.trim();

  const isNameChanged = trimmedName !== currentTrimmedName;
  const isPhoneChanged = trimmedPhone !== currentTrimmedPhone;
  const isChanged = isNameChanged || isPhoneChanged;

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Only allow numbers and limit to 11 digits
    const cleanNumbers = e.target.value.replace(/\D/g, '').slice(0, 11);
    setPhone(cleanNumbers);
    if (error) setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!trimmedName) {
      setError(t('modals.enterDebtorNameError', 'يرجى كتابة اسم المدين'));
      return;
    }

    if (trimmedName.length < 2) {
      setError(t('modals.nameMin2Chars', 'يجب أن يتكون الاسم من حرفين على الأقل'));
      return;
    }

    if (requireCustomerPhone && !trimmedPhone) {
      setError('رقم هاتف العميل إلزامي بتوجيه من الإدارة العامة، يرجى إدخال رقم الهاتف للمتابعة');
      return;
    }

    if (trimmedPhone && trimmedPhone.length !== 11) {
      setError(
        requireCustomerPhone
          ? 'رقم هاتف العميل إلزامي ويجب أن يتكون من 11 رقماً'
          : t('modals.phone11DigitsError', 'رقم الهاتف يجب أن يتكون من 11 رقماً فقط (أو اتركه فارغاً)')
      );
      return;
    }

    if (!isChanged) {
      onClose();
      return;
    }

    if (isNameChanged && nameCheckResult.hasExactMatch && !allowDuplicateName) {
      setError(`يوجد حساب مسجل مسبقاً باسم "${nameCheckResult.exactMatch?.name}". يرجى اختيار اسم مميز لتجنب التكرار أو تفعيل خيار السماح بالتكرار.`);
      return;
    }

    try {
      setIsSubmitting(true);
      setError(null);
      await onSave(debtor.id, trimmedName, trimmedPhone);
      onClose();
    } catch (err: any) {
      setError(err?.message || t('common.errorOccurred', 'حدث خطأ أثناء حفظ التعديلات'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl border border-slate-100 text-start animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-base shadow-xs shrink-0">
              <i className="fa-solid fa-user-pen"></i>
            </div>
            <div>
              <h3 className="font-black text-slate-900 text-base leading-tight">
                {t('debtors.editDebtorInfo', 'تعديل بيانات المدين')}
              </h3>
              <p className="text-[11.5px] text-slate-400 font-medium">
                {t('debtors.updateNameAndPhone', 'تحديث الاسم ورقم الهاتف')}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center cursor-pointer transition-colors"
            title={t('common.close', 'إغلاق')}
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Current Debtor Context Badge */}
        <div className="bg-slate-50 border border-slate-100 rounded-2xl p-3 mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-white border border-slate-200/80 text-blue-700 font-bold flex items-center justify-center text-xs shadow-2xs shrink-0">
              {initialLetter}
            </div>
            <div className="min-w-0">
              <div className="text-[11px] text-slate-400 font-medium">{t('debtors.currentInfo', 'البيانات الحالية')}</div>
              <div className="font-bold text-xs text-slate-800 truncate" title={debtor.name}>
                {debtor.name}
              </div>
              {debtor.phone && (
                <div className="text-[10.5px] text-slate-500 font-mono" dir="ltr">
                  {debtor.phone}
                </div>
              )}
            </div>
          </div>
          <div className="text-end shrink-0 font-mono">
            <div className="text-[10px] text-slate-400 font-sans">{t('debts.totalDebt', 'الرصيد القائم')}</div>
            <div className="font-black text-xs text-slate-700">
              {formatNumber(debtor.amount)} <span className="text-[9px] font-sans">{currency}</span>
            </div>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Name Field */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              {t('debts.debtorName', 'اسم المدين')} <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                ref={inputRef}
                type="text"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (error) setError(null);
                }}
                className="w-full bg-slate-50 border border-slate-200 focus:border-blue-500 focus:bg-white rounded-xl px-3.5 py-2.5 text-sm text-slate-800 font-medium focus:outline-hidden transition-all"
                disabled={isSubmitting}
                maxLength={60}
              />
              {name && (
                <button
                  type="button"
                  onClick={() => {
                    setName('');
                    inputRef.current?.focus();
                  }}
                  className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                >
                  <i className="fa-solid fa-circle-xmark text-xs"></i>
                </button>
              )}
            </div>
            <NameDuplicateAlert
              checkResult={nameCheckResult}
              currency={currency}
              allowSameNameAnyway={allowDuplicateName}
              onToggleAllowSameName={setAllowDuplicateName}
            />
          </div>

          {/* Phone Field */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <i className={`fa-solid fa-phone ${requireCustomerPhone ? 'text-blue-600' : 'text-slate-400'} text-xs`}></i>
                <span>{t('debts.phoneNumber', 'رقم الهاتف')}</span>
                {requireCustomerPhone && <span className="text-rose-500 font-extrabold">*</span>}
              </span>
              <span className={`text-[10.5px] font-bold px-2 py-0.5 rounded-md transition-colors ${
                requireCustomerPhone
                  ? 'bg-rose-50 text-rose-700 border border-rose-200'
                  : 'text-slate-400 font-normal'
              }`}>
                {requireCustomerPhone ? 'إلزامي بتوجيه الإدارة' : t('common.optional', 'اختياري')}
              </span>
            </label>
            <div className="relative">
              <input
                type="tel"
                dir="ltr"
                required={requireCustomerPhone}
                value={phone}
                onChange={handlePhoneChange}
                maxLength={11}
                placeholder={requireCustomerPhone ? '07XXXXXXXXX (11 رقماً مطلوب)' : '07XXXXXXXXX'}
                className={`w-full bg-slate-50 border focus:bg-white rounded-xl px-3.5 py-2.5 text-sm text-slate-800 font-mono focus:outline-hidden transition-all ${
                  requireCustomerPhone
                    ? 'border-blue-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-500/20'
                    : 'border-slate-200 focus:border-blue-500'
                }`}
                disabled={isSubmitting}
              />
              <div className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs">
                <i className="fa-solid fa-phone"></i>
              </div>
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-2.5 bg-red-50 border border-red-200 text-red-600 text-xs rounded-xl flex items-center gap-2">
              <i className="fa-solid fa-triangle-exclamation shrink-0 text-xs"></i>
              <span>{error}</span>
            </div>
          )}

          {/* Buttons */}
          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold cursor-pointer transition-colors"
              disabled={isSubmitting}
            >
              {t('common.cancel', 'إلغاء')}
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !trimmedName || !isChanged}
              className={`flex-2 py-2.5 rounded-xl text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-all ${
                isSubmitting || !trimmedName || !isChanged
                  ? 'bg-slate-300 cursor-not-allowed shadow-none'
                  : 'bg-blue-600 hover:bg-blue-700 active:scale-[0.99]'
              }`}
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>{t('common.saving', 'جاري الحفظ...')}</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-check text-xs"></i>
                  <span>{t('debtors.saveChanges', 'حفظ التعديلات')}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
