import React, { useState, useEffect, useRef } from 'react';
import { Supplier } from '../types';
import { formatNumber, formatAmountInput, parseFormattedNumber, getCurrentTimeStr, resolveRecordDateTime, getArabicCurrencyLabel, formatAmountInArabicWords } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';
import { handleInputFocus, useModalKeyboardAdjust } from '../utils/keyboardHelper';
import { RecordTimeSelector } from './RecordTimeSelector';
import { InvoiceAttachmentField } from './InvoiceAttachmentField';

interface SupplierAddDebtModalProps {
  supplier: Supplier | null;
  isOpen: boolean;
  onClose: () => void;
  onAddDebt: (supplierId: number, addedAmount: number, notes?: string, txDate?: string, itemType?: string, invoiceImage?: string) => void;
  currencySymbol?: string;
  allowInvoiceUpload?: boolean;
}

export const SupplierAddDebtModal: React.FC<SupplierAddDebtModalProps> = ({
  supplier,
  isOpen,
  onClose,
  onAddDebt,
  currencySymbol = 'د.ع',
  allowInvoiceUpload = true,
}) => {
  const { numberFormat } = useI18n();
  const [addAmount, setAddAmount] = useState('');
  const [itemType, setItemType] = useState('');
  const [notes, setNotes] = useState('');
  const [invoiceImage, setInvoiceImage] = useState<string | undefined>(undefined);
  const [debtDate, setDebtDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [recordTime, setRecordTime] = useState(true);
  const [timeMode, setTimeMode] = useState<'auto' | 'manual'>('auto');
  const [debtTime, setDebtTime] = useState(() => getCurrentTimeStr());

  const prevIsOpenRef = useRef(false);
  const prevSupplierIdRef = useRef<number | null>(null);

  useModalKeyboardAdjust(isOpen);

  const todayStr = new Date().toISOString().split('T')[0];

  // Reset fields ONLY when the modal transitions from closed to open, or when supplier ID actually changes
  useEffect(() => {
    if (isOpen && supplier) {
      const isJustOpened = !prevIsOpenRef.current;
      const isDifferentSupplier = prevSupplierIdRef.current !== supplier.id;

      if (isJustOpened || isDifferentSupplier) {
        setItemType('');
        setNotes('');
        setAddAmount('');
        setInvoiceImage(undefined);
        setDebtDate(new Date().toISOString().split('T')[0]);
        setRecordTime(true);
        setTimeMode('auto');
        setDebtTime(getCurrentTimeStr());
      }
    }
    prevIsOpenRef.current = isOpen;
    prevSupplierIdRef.current = supplier ? supplier.id : null;
  }, [supplier?.id, isOpen]);

  if (!isOpen || !supplier) return null;

  const currentAmount = supplier.amount || 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFormattedNumber(addAmount);
    if (isNaN(numAmount) || numAmount <= 0) {
      alert('يرجى كتابة مبلغ الدين المضاف بشكل صحيح.');
      return;
    }

    const fullDebtDateTime = resolveRecordDateTime(debtDate, recordTime, timeMode, debtTime);

    onAddDebt(
      supplier.id,
      numAmount,
      notes.trim() || undefined,
      fullDebtDateTime,
      itemType.trim() || undefined,
      invoiceImage
    );

    // Reset & Close
    setAddAmount('');
    setItemType('');
    setNotes('');
    setInvoiceImage(undefined);
    onClose();
  };

  const supplierDisplayName = typeof supplier.name === 'string' ? supplier.name : String(supplier.name || '');
  const companyNameStr = typeof supplier.companyName === 'string' && supplier.companyName.trim() ? `(${supplier.companyName.trim()})` : '';
  const isUsd = (supplier.currency || currencySymbol) === 'USD' || currencySymbol === '$';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200 overflow-y-auto">
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col my-auto max-h-[92vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className={`p-4 text-white flex items-center justify-between shrink-0 ${
          isUsd
            ? 'bg-gradient-to-r from-indigo-700 via-violet-800 to-slate-900'
            : 'bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/20 flex items-center justify-center text-lg shrink-0">
              <i className={`fa-solid fa-cart-plus ${isUsd ? 'text-indigo-100' : 'text-amber-100'}`}></i>
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base">إضافة دين / شحنة جديدة للمورد</h3>
              <p className={`text-[11px] font-medium ${isUsd ? 'text-indigo-100/90' : 'text-amber-100/90'}`}>تسجيل شحنة بضاعة بالأجل لحساب المورد</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 sm:w-9 sm:h-9 rounded-xl bg-white/15 hover:bg-white/25 active:bg-white/35 active:scale-95 text-white flex items-center justify-center transition-all cursor-pointer touch-manipulation border border-white/10 shadow-xs"
            title="خروج / إغلاق"
            aria-label="إغلاق النافذة"
          >
            <i className="fa-solid fa-xmark text-base"></i>
          </button>
        </div>

        {/* Info Banner */}
        <div className={`p-3.5 border-b text-start flex items-center justify-between ${
          isUsd
            ? 'bg-indigo-50/60 dark:bg-indigo-950/20 border-indigo-200/80 dark:border-indigo-800/40'
            : 'bg-amber-50/60 dark:bg-amber-950/20 border-amber-200/80 dark:border-amber-800/40'
        }`}>
          <div>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold block">اسم المورد / الشركة</span>
            <span className="text-xs font-black text-slate-900 dark:text-white">
              {supplierDisplayName} {companyNameStr}
            </span>
          </div>
          <div className="text-left">
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold block">الدين الحالي للمورد</span>
            <span className={`text-sm font-black font-mono ${isUsd ? 'text-indigo-600 dark:text-indigo-400' : 'text-amber-600 dark:text-amber-400'}`}>
              {formatNumber(currentAmount, numberFormat)} {isUsd ? 'دولار ($)' : 'دينار (د.ع)'}
            </span>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3.5 text-start overflow-y-auto">
          {/* Debt Amount */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between gap-1.5 flex-wrap">
              <span>مبلغ الدين / البضاعة الجديد <span className="text-rose-500">*</span></span>
              <span className={`text-[10.5px] font-extrabold px-2 py-0.5 rounded-lg border ${
                isUsd
                  ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                  : 'bg-amber-50 text-amber-800 border-amber-200'
              }`}>
                {getArabicCurrencyLabel(isUsd ? 'USD' : 'IQD')}
              </span>
            </label>
            <div className="relative flex items-center">
              <input
                type="text"
                inputMode="numeric"
                required
                value={addAmount}
                onFocus={handleInputFocus}
                onChange={(e) => setAddAmount(formatAmountInput(e.target.value))}
                placeholder="0"
                className={`w-full pl-16 pr-3.5 py-3 rounded-2xl text-base font-black outline-none transition-all border ${
                  isUsd
                    ? 'bg-indigo-50/50 dark:bg-indigo-950/20 border-indigo-300 dark:border-indigo-800/80 text-indigo-900 dark:text-indigo-200 focus:border-indigo-600 focus:ring-2 focus:ring-indigo-500/30'
                    : 'bg-amber-50/50 dark:bg-amber-950/20 border-amber-300 dark:border-amber-800/80 text-amber-900 dark:text-amber-200 focus:border-amber-600 focus:ring-2 focus:ring-amber-500/30'
                }`}
              />
              <span className={`absolute left-3 text-xs font-extrabold ${
                isUsd ? 'text-indigo-700 dark:text-indigo-400' : 'text-amber-700 dark:text-amber-400'
              }`}>
                {isUsd ? 'دولار $' : 'دينار د.ع'}
              </span>
            </div>
            {parseFormattedNumber(addAmount) > 0 && (
              <div className={`text-[11px] font-bold px-2.5 py-1.5 rounded-xl border flex items-center gap-1.5 ${
                isUsd
                  ? 'bg-indigo-50/70 text-indigo-800 border-indigo-200/70'
                  : 'bg-amber-50/70 text-amber-900 border-amber-200/70'
              }`}>
                <i className="fa-solid fa-spell-check text-[10px] opacity-75"></i>
                <span>كتابةً: {formatAmountInArabicWords(addAmount, isUsd ? 'USD' : 'IQD')}</span>
              </div>
            )}
          </div>

          {/* Item Type (Goods Details for this shipment) */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              نوع وتفاصيل البضاعة / المواد للشحنة
            </label>
            <textarea
              rows={2}
              value={itemType}
              onFocus={handleInputFocus}
              onChange={(e) => setItemType(e.target.value)}
              placeholder=""
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all resize-none leading-relaxed"
            />
          </div>

          {/* Debt Date */}
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">تاريخ تسجيل الدين</label>
              {debtDate !== todayStr ? (
                <button
                  type="button"
                  onClick={() => setDebtDate(todayStr)}
                  className="text-[10px] font-bold text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 px-1.5 py-0.5 rounded cursor-pointer transition-colors"
                >
                  اليوم
                </button>
              ) : (
                <span className="text-[10px] text-amber-700 dark:text-amber-400 font-bold bg-amber-50 dark:bg-amber-950/40 px-1.5 py-0.5 rounded border border-amber-200 dark:border-amber-800">
                  اليوم
                </span>
              )}
            </div>
            <input
              type="date"
              value={debtDate}
              onFocus={handleInputFocus}
              onChange={(e) => setDebtDate(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all font-mono"
            />
          </div>

          {/* Record Time Selector */}
          <RecordTimeSelector
            enabled={recordTime}
            onEnabledChange={setRecordTime}
            mode={timeMode}
            onModeChange={setTimeMode}
            time={debtTime}
            onTimeChange={setDebtTime}
            accentColor="amber"
            idPrefix="sup_add_debt"
          />

          {/* Notes / Invoice details */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              ملاحظات أو رقم الوصل/الفاتورة للشحنة
            </label>
            <textarea
              rows={2}
              value={notes}
              onFocus={handleInputFocus}
              onChange={(e) => setNotes(e.target.value)}
              placeholder=""
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all resize-none leading-relaxed"
            />
          </div>

          {/* Invoice Attachment Field */}
          <InvoiceAttachmentField
            value={invoiceImage}
            onChange={setInvoiceImage}
            allowUpload={allowInvoiceUpload}
            label="صورة فاتورة / وصل شحنة الدين (اختياري)"
          />

          {/* Actions */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2.5 pb-[max(0.75rem,calc(env(safe-area-inset-bottom)+0.25rem))]">
            <button
              type="submit"
              className={`flex-1 min-h-[48px] py-3 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition-all cursor-pointer active:scale-[0.98] flex items-center justify-center gap-2 touch-manipulation ${
                isUsd
                  ? 'bg-gradient-to-r from-indigo-600 to-violet-700 hover:from-indigo-700 active:from-indigo-800'
                  : 'bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 active:from-amber-800'
              }`}
            >
              <i className="fa-solid fa-plus text-xs"></i>
              <span>حفظ وإضافة الدين الآن</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[48px] py-3 px-5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl text-xs sm:text-sm transition-all cursor-pointer active:scale-[0.98] touch-manipulation border border-slate-200/50 dark:border-slate-700/50"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
