import React, { useState, useEffect } from 'react';
import { InstallmentRecord } from '../types';
import { useI18n } from '../i18n/index.tsx';
import { formatNumber, formatAmountInput, parseFormattedNumber, toEnglishDigits, getCurrentTimeStr, resolveRecordDateTime, getArabicCurrencyShort, formatAmountInArabicWords } from '../utils/formatters';
import { handleInputFocus, useModalKeyboardAdjust } from '../utils/keyboardHelper';
import { RecordTimeSelector } from './RecordTimeSelector';
import { InvoiceAttachmentField } from './InvoiceAttachmentField';

interface SettleInstallmentPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  installment: InstallmentRecord;
  onSettle: (installmentId: number, paidAmount: number, paymentDate: string, notes?: string, paymentMethod?: 'cash' | 'electronic', invoiceImage?: string) => Promise<void>;
  enableElectronicPayment?: boolean;
  allowInvoiceUpload?: boolean;
}

export const SettleInstallmentPaymentModal: React.FC<SettleInstallmentPaymentModalProps> = ({
  isOpen,
  onClose,
  installment,
  onSettle,
  enableElectronicPayment = false,
  allowInvoiceUpload = true,
}) => {
  const { t, currency } = useI18n();
  const [paidAmountStr, setPaidAmountStr] = useState('');
  const [paymentDate, setPaymentDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [recordTime, setRecordTime] = useState(true);
  const [timeMode, setTimeMode] = useState<'auto' | 'manual'>('auto');
  const [paymentTime, setPaymentTime] = useState(() => getCurrentTimeStr());
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'electronic'>('cash');
  const [notes, setNotes] = useState('');
  const [invoiceImage, setInvoiceImage] = useState<string | undefined>(undefined);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useModalKeyboardAdjust(isOpen);

  const todayStr = new Date().toISOString().split('T')[0];

  useEffect(() => {
    if (isOpen) {
      setPaidAmountStr('');
      setPaymentDate(new Date().toISOString().split('T')[0]);
      setRecordTime(true);
      setTimeMode('auto');
      setPaymentTime(getCurrentTimeStr());
      setNotes('');
      setInvoiceImage(undefined);
      setErrorMsg(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const effectiveCurrency = installment.currency || currency;
  const isUsd = effectiveCurrency === 'USD';
  const paidAmount = parseFormattedNumber(paidAmountStr);
  const remainingAfter = Math.max(0, installment.remainingAmount - paidAmount);
  const isFullSettlement = paidAmount >= installment.remainingAmount;

  const handleQuickPreset = (amount: number) => {
    setPaidAmountStr(amount.toLocaleString('en-US'));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (paidAmount <= 0) {
      setErrorMsg(t('modals.enterPaymentAmountError', 'يرجى إدخال مبلغ الدفعة بشكل صحيح'));
      return;
    }
    if (paidAmount > installment.remainingAmount) {
      setErrorMsg(t('modals.paymentExceedsRemainingError', 'المبلغ المدخل أكبر من المبلغ المتبقي على صاحب الأقساط'));
      return;
    }

    try {
      setIsSubmitting(true);
      const fullPaymentDate = resolveRecordDateTime(paymentDate, recordTime, timeMode, paymentTime);
      await onSettle(
        installment.id,
        paidAmount,
        fullPaymentDate,
        notes.trim() || undefined,
        paymentMethod,
        invoiceImage
      );
      setInvoiceImage(undefined);
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || t('common.errorOccurred', 'فشل تسجيل الدفعة'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/60 backdrop-blur-xs p-0 sm:p-4 animate-in fade-in duration-150 text-start">
      <div className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-100 flex flex-col max-h-[92dvh] overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-teal-700 via-emerald-800 to-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/10 flex items-center justify-center text-teal-300 border border-white/10">
              <i className="fa-solid fa-money-bill-wave text-base"></i>
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">{t('installments.settlePayment', 'تسديد دفعة / قسط شهري')}</h2>
              <p className="text-[10.5px] text-teal-200/80 mt-0.5 font-medium">
                {installment.name} • {installment.item}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 sm:w-9 sm:h-9 rounded-xl bg-white/15 hover:bg-white/25 active:bg-white/35 active:scale-95 text-white flex items-center justify-center transition-all cursor-pointer touch-manipulation border border-white/10 shadow-xs"
            title="خروج / إغلاق"
            aria-label="إغلاق النافذة"
          >
            <i className="fa-solid fa-xmark text-base"></i>
          </button>
        </div>

        {/* Content - Scrollable Form */}
        <form onSubmit={handleSubmit} className="p-5 pb-28 sm:pb-5 overflow-y-auto space-y-4 overscroll-contain flex-1">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
              <i className="fa-solid fa-circle-exclamation shrink-0"></i>
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Current Balance Overview */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-slate-500 block">{t('installments.currentRemaining', 'المبلغ المتبقي حالياً')}:</span>
              <span className="text-xs font-semibold text-slate-700">{installment.item}</span>
            </div>
            <div className="text-left">
              <span className="text-lg font-black text-rose-600 font-mono">
                {formatNumber(installment.remainingAmount)}
              </span>
              <span className="text-xs font-bold text-slate-500 mr-1">{isUsd ? 'دولار ($)' : 'دينار (د.ع)'}</span>
            </div>
          </div>

          {/* Payment Amount Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between flex-wrap gap-1">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-solid fa-hand-holding-dollar text-teal-600 text-xs"></i>
                <span>{t('installments.receivedPaymentAmount', 'مبلغ الدفعة المستلمة')} ({getArabicCurrencyShort(effectiveCurrency)})</span>
                <span className="text-rose-500">*</span>
              </label>
              <button
                type="button"
                onClick={() => handleQuickPreset(installment.remainingAmount)}
                className="text-[11px] font-bold text-teal-700 hover:text-teal-800 bg-teal-50 px-2.5 py-1 rounded-lg border border-teal-200 cursor-pointer transition-colors"
              >
                {t('installments.payFullRemaining', 'تسديد كامل المتبقي')}
              </button>
            </div>
            <div className="relative flex items-center">
              <input
                type="text"
                dir="ltr"
                inputMode="numeric"
                required
                placeholder="0"
                value={paidAmountStr}
                onChange={(e) => setPaidAmountStr(formatAmountInput(e.target.value))}
                onFocus={handleInputFocus}
                className="w-full pl-14 pr-3.5 py-3 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-900 rounded-xl text-sm font-black font-mono border border-slate-200 focus:border-teal-600 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all"
              />
              <span className={`absolute left-3 text-xs font-extrabold pointer-events-none ${
                isUsd ? 'text-cyan-700' : 'text-teal-700'
              }`}>
                {isUsd ? 'دولار $' : 'دينار د.ع'}
              </span>
            </div>
            {paidAmount > 0 && (
              <div className={`text-[11px] font-bold px-2.5 py-1.5 rounded-xl border flex items-center gap-1.5 ${
                isUsd ? 'bg-cyan-50/70 text-cyan-800 border-cyan-200/70' : 'bg-teal-50/70 text-teal-800 border-teal-200/70'
              }`}>
                <i className="fa-solid fa-spell-check text-[10px] opacity-75"></i>
                <span>كتابةً: {formatAmountInArabicWords(paidAmount, effectiveCurrency)}</span>
              </div>
            )}
          </div>

          {/* Calculation Summary */}
          {paidAmount > 0 && (
            <div className={`p-3 rounded-2xl border transition-all ${
              isFullSettlement
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-teal-50 border-teal-200 text-teal-900'
            }`}>
              <div className="flex items-center justify-between text-xs font-bold">
                <span>{t('installments.remainingAfterPayment', 'المتبقي بعد هذه الدفعة')}:</span>
                <span className="font-mono text-sm">
                  {formatNumber(remainingAfter)} {isUsd ? 'دولار ($)' : 'دينار (د.ع)'}
                </span>
              </div>
              {isFullSettlement ? (
                <p className="text-[11px] text-emerald-700 mt-1 font-medium flex items-center gap-1">
                  <i className="fa-solid fa-circle-check text-emerald-600"></i>
                  <span>{t('installments.willBeClosedFullSettlement', 'سيتم إغلاق القسط وتسجيله كـ "مسدد بالكامل"')}</span>
                </p>
              ) : (
                <p className="text-[11px] text-teal-700 mt-1 font-medium flex items-center gap-1">
                  <i className="fa-solid fa-calendar-check text-teal-600"></i>
                  <span>{t('installments.nextDueDateAutoDeferred', 'سيتم ترحيل موعد الاستحقاق القادم تلقائياً إلى الشهر التالي')}</span>
                </p>
              )}
            </div>
          )}

          {/* Payment Method Switcher - Shown only when electronic payment is enabled */}
          {enableElectronicPayment && (
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <i className="fa-solid fa-credit-card text-teal-600 text-xs"></i>
                  <span>{t('debts.paymentMethod', 'طريقة الدفع والتسديد')}</span>
                </span>
                <span className="text-[10.5px] font-bold text-slate-500">
                  {paymentMethod === 'electronic' ? '💳 دفع إلكتروني (ماستر كارد)' : '💵 نقداً (كاش)'}
                </span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('cash')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                    paymentMethod === 'cash'
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-xs ring-2 ring-emerald-500/20'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <span className="text-sm">💵</span>
                  <span>{t('debts.cashPayment', 'نقداً (كاش)')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('electronic')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                    paymentMethod === 'electronic'
                      ? 'bg-teal-50 border-teal-500 text-teal-700 shadow-xs ring-2 ring-teal-500/20'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <span className="text-sm">💳</span>
                  <span>{t('debts.electronicPayment', 'دفع إلكتروني')}</span>
                </button>
              </div>
            </div>
          )}

          {/* Payment Date */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-solid fa-calendar-day text-teal-600 text-xs"></i>
                <span>{t('common.date', 'تاريخ استلام الدفعة')}</span>
              </label>
              {paymentDate !== todayStr ? (
                <button
                  type="button"
                  onClick={() => setPaymentDate(todayStr)}
                  className="text-[10px] font-bold text-teal-700 hover:text-teal-800 bg-teal-50 hover:bg-teal-100 px-1.5 py-0.5 rounded cursor-pointer transition-colors"
                >
                  اليوم
                </button>
              ) : (
                <span className="text-[10px] text-teal-700 font-bold bg-teal-50 px-1.5 py-0.5 rounded border border-teal-100">
                  اليوم
                </span>
              )}
            </div>
            <input
              type="date"
              required
              value={paymentDate}
              onChange={(e) => setPaymentDate(toEnglishDigits(e.target.value))}
              onFocus={handleInputFocus}
              className="w-full px-3 py-2 bg-slate-50 text-slate-800 rounded-xl text-xs font-semibold border border-slate-200 focus:border-teal-600 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all font-mono"
            />
          </div>

          {/* Record Time Selector */}
          <RecordTimeSelector
            enabled={recordTime}
            onEnabledChange={setRecordTime}
            mode={timeMode}
            onModeChange={setTimeMode}
            time={paymentTime}
            onTimeChange={setPaymentTime}
            accentColor="teal"
            idPrefix="settle_inst"
          />

          {/* Notes */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-note-sticky text-slate-400 text-xs"></i>
              <span>{t('common.notes', 'ملاحظة الدفعة')} ({t('common.optional', 'اختياري')})</span>
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              onFocus={handleInputFocus}
              className="w-full px-3.5 py-2.5 bg-slate-50 text-slate-800 rounded-xl text-xs font-medium border border-slate-200 focus:border-teal-600 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all"
            />
          </div>

          {/* Invoice Attachment Field */}
          <InvoiceAttachmentField
            value={invoiceImage}
            onChange={setInvoiceImage}
            allowUpload={allowInvoiceUpload}
            label="صورة وصل تسديد القسط (اختياري)"
          />

          {/* Actions */}
          <div className="flex items-center gap-2.5 pt-3 border-t border-slate-100 pb-[max(0.75rem,calc(env(safe-area-inset-bottom)+0.5rem))]">
            <button
              type="submit"
              disabled={isSubmitting || paidAmount <= 0}
              className="flex-1 min-h-[48px] py-3 px-4 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 active:from-teal-800 text-white text-xs sm:text-sm font-extrabold shadow-md shadow-teal-600/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 touch-manipulation"
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>{t('common.saving', 'جاري تسجيل الدفعة...')}</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-check text-xs"></i>
                  <span>{t('installments.confirmPayment', 'تأكيد استلام الدفعة')}</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[48px] py-3 px-5 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-slate-300 active:scale-[0.98] text-slate-700 text-xs sm:text-sm font-bold transition-all cursor-pointer touch-manipulation border border-slate-200/50"
            >
              {t('common.cancel', 'إلغاء')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
