import React, { useState, useMemo } from 'react';
import { Debtor, InstallmentRecord } from '../types';
import { useI18n } from '../i18n/index.tsx';
import { formatAmountInput, parseFormattedNumber, formatNumber, getCurrentTimeStr, resolveRecordDateTime, getArabicCurrencyLabel, getArabicCurrencyShort, formatAmountInArabicWords } from '../utils/formatters';
import { calculateNextMonthDueDate, computeInstallmentStatus } from '../utils/installmentHelpers';
import { handleInputFocus, useModalKeyboardAdjust } from '../utils/keyboardHelper';
import { RecordTimeSelector } from './RecordTimeSelector';
import { InvoiceAttachmentField } from './InvoiceAttachmentField';
import { checkNameDuplicate, ExistingNameRecord } from '../utils/nameDuplicateChecker';
import { NameDuplicateAlert } from './NameDuplicateAlert';

interface UnifiedAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: 'debt' | 'installment';
  initialMode?: 'debt' | 'installment';
  allowInvoiceUpload?: boolean;
  onSaveDebtor: (name: string, phone: string, amount: number, debtDate?: string, notes?: string, type?: 'debtor' | 'creditor', invoiceImage?: string) => Promise<void>;
  onSaveInstallment: (inst: Omit<InstallmentRecord, 'id'>) => Promise<void>;
  userId: number;
  existingDebtors?: Debtor[];
  existingInstallments?: InstallmentRecord[];
  onSelectExistingDebtor?: (debtor: Debtor) => void;
  onSelectExistingInstallment?: (inst: InstallmentRecord) => void;
}

export const UnifiedAddModal: React.FC<UnifiedAddModalProps> = ({
  isOpen,
  onClose,
  initialType,
  initialMode,
  allowInvoiceUpload = true,
  onSaveDebtor,
  onSaveInstallment,
  userId,
  existingDebtors = [],
  existingInstallments = [],
  onSelectExistingDebtor,
  onSelectExistingInstallment,
}) => {
  const { t, currency } = useI18n();
  const isUsd = currency === 'USD';
  const effectiveInitial = initialType || initialMode || 'debt';
  const [entryType, setEntryType] = useState<'debt' | 'installment'>(effectiveInitial);
  const [invoiceImage, setInvoiceImage] = useState<string | undefined>(undefined);
  const [allowDuplicateName, setAllowDuplicateName] = useState(false);

  useModalKeyboardAdjust(isOpen);

  // Common Fields
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [recordTime, setRecordTime] = useState(true);
  const [timeMode, setTimeMode] = useState<'auto' | 'manual'>('auto');
  const [time, setTime] = useState(() => getCurrentTimeStr());

  // Debt Specific Fields
  const [debtAmountStr, setDebtAmountStr] = useState('');

  // Installment Specific Fields
  const [item, setItem] = useState('');
  const [totalInstallmentAmountStr, setTotalInstallmentAmountStr] = useState('');
  const [downPaymentStr, setDownPaymentStr] = useState('');
  const [nationalId, setNationalId] = useState('');
  const [address, setAddress] = useState('');

  // Guarantor Fields
  const [guarantorEnabled, setGuarantorEnabled] = useState(false);
  const [guarantorName, setGuarantorName] = useState('');
  const [guarantorAddress, setGuarantorAddress] = useState('');
  const [guarantorJob, setGuarantorJob] = useState('');
  const [guarantorRelation, setGuarantorRelation] = useState('');
  const [guarantorPhone, setGuarantorPhone] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Existing records pool based on current entryType
  const candidateRecords: ExistingNameRecord[] = useMemo(() => {
    if (entryType === 'debt') {
      return (existingDebtors || []).map((d) => ({
        id: d.id,
        name: d.name,
        phone: d.phone,
        amount: d.amount,
        type: d.type || 'debtor',
      }));
    } else {
      return (existingInstallments || []).map((inst) => ({
        id: inst.id,
        name: inst.name,
        phone: inst.phone,
        amount: inst.remainingAmount,
        type: 'installment',
      }));
    }
  }, [entryType, existingDebtors, existingInstallments]);

  const nameCheckResult = useMemo(() => {
    return checkNameDuplicate(name, candidateRecords);
  }, [name, candidateRecords]);

  // Sync entryType if initialType/initialMode changes upon opening
  React.useEffect(() => {
    if (isOpen) {
      setEntryType(initialType || initialMode || 'debt');
      setError(null);
      setAllowDuplicateName(false);
    }
  }, [isOpen, initialType, initialMode]);

  if (!isOpen) return null;

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const cleanNumbers = e.target.value.replace(/\D/g, '').slice(0, 11);
    setPhone(cleanNumbers);
    if (error) setError(null);
  };

  const handleNationalIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const cleanNumbers = e.target.value.replace(/\D/g, '').slice(0, 12);
    setNationalId(cleanNumbers);
    if (error) setError(null);
  };

  const handleGuarantorPhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const cleanNumbers = e.target.value.replace(/\D/g, '').slice(0, 11);
    setGuarantorPhone(cleanNumbers);
    if (error) setError(null);
  };

  const parsedTotalInst = parseFormattedNumber(totalInstallmentAmountStr);
  const parsedDownPayment = parseFormattedNumber(downPaymentStr);
  const calculatedRemaining = Math.max(0, parsedTotalInst - parsedDownPayment);
  const calculatedNextDueDate = calculateNextMonthDueDate(date);

  const resetForm = () => {
    setName('');
    setPhone('');
    setNotes('');
    setDate(new Date().toISOString().split('T')[0]);
    setRecordTime(true);
    setTimeMode('auto');
    setTime(getCurrentTimeStr());
    setDebtAmountStr('');
    setItem('');
    setTotalInstallmentAmountStr('');
    setDownPaymentStr('');
    setNationalId('');
    setAddress('');
    setGuarantorEnabled(false);
    setGuarantorName('');
    setGuarantorAddress('');
    setGuarantorJob('');
    setGuarantorRelation('');
    setGuarantorPhone('');
    setInvoiceImage(undefined);
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedName = name.trim();
    if (!trimmedName) {
      setError(t('modals.enterDebtorNameError', 'يرجى كتابة الاسم أولاً'));
      return;
    }

    if (nameCheckResult.hasExactMatch && !allowDuplicateName) {
      setError(`يوجد حساب مسجل مسبقاً باسم "${nameCheckResult.exactMatch?.name}". يرجى فتح حسابه أو تفعيل خيار السماح بالتكرار.`);
      return;
    }

    const trimmedPhone = phone.trim();
    if (trimmedPhone && trimmedPhone.length !== 11) {
      setError(t('modals.phone11DigitsError', 'رقم الهاتف يجب أن يتكون من 11 رقماً (أو اتركه فارغاً)'));
      return;
    }

    try {
      setIsSubmitting(true);

      if (entryType === 'debt') {
        const numericAmount = parseFormattedNumber(debtAmountStr);
        if (!debtAmountStr.trim() || isNaN(numericAmount) || numericAmount <= 0) {
          setError('يرجى كتابة مبلغ الدين أولاً (يجب أن يكون أكبر من 0)');
          setIsSubmitting(false);
          return;
        }
        const effectiveDebtDate = resolveRecordDateTime(date, recordTime, timeMode, time);
        await onSaveDebtor(
          trimmedName,
          trimmedPhone,
          numericAmount,
          effectiveDebtDate,
          notes.trim() || undefined,
          'debtor',
          invoiceImage
        );
      } else {
        const trimmedItem = item.trim();
        if (!trimmedItem) {
          setError(t('modals.enterItemNameError', 'يرجى كتابة اسم السلعة أو الغرض المقسط'));
          setIsSubmitting(false);
          return;
        }
        if (!totalInstallmentAmountStr.trim() || isNaN(parsedTotalInst) || parsedTotalInst <= 0) {
          setError(t('modals.enterTotalAmountError', 'يرجى كتابة مبلغ الأقساط الإجمالي أولاً (أكبر من 0)'));
          setIsSubmitting(false);
          return;
        }
        if (parsedDownPayment > parsedTotalInst) {
          setError(t('modals.downPaymentTooLargeError', 'لا يمكن أن تكون الدفعة المقدمة أكبر من المبلغ الإجمالي'));
          setIsSubmitting(false);
          return;
        }

        const trimmedNatId = nationalId.trim();
        if (trimmedNatId && trimmedNatId.length !== 12) {
          setError(t('modals.nationalId12DigitsError', 'رقم البطاقة الوطنية يجب أن يتكون من 12 رقماً (أو اتركه فارغاً)'));
          setIsSubmitting(false);
          return;
        }

        const trimmedGPhone = guarantorPhone.trim();
        if (guarantorEnabled && trimmedGPhone && trimmedGPhone.length !== 11) {
          setError(t('modals.guarantorPhone11DigitsError', 'رقم هاتف الكفيل يجب أن يتكون من 11 رقماً (أو اتركه فارغاً)'));
          setIsSubmitting(false);
          return;
        }

        const fullDateTime = resolveRecordDateTime(date, recordTime, timeMode, time);
        const initialPayments = parsedDownPayment > 0 ? [
          {
            id: `down-${Date.now()}`,
            installmentId: 0,
            amount: parsedDownPayment,
            date: fullDateTime,
            remainingAfter: calculatedRemaining,
            notes: t('installments.downPaymentNote', 'دفعة مقدمة عند تسجيل القسط'),
            invoiceImage,
          }
        ] : [];

        const status = computeInstallmentStatus({
          remainingAmount: calculatedRemaining,
          nextDueDate: calculatedNextDueDate,
          registrationDate: date,
        });

        await onSaveInstallment({
          name: trimmedName,
          phone: trimmedPhone,
          item: trimmedItem,
          totalAmount: parsedTotalInst,
          downPayment: parsedDownPayment,
          remainingAmount: calculatedRemaining,
          registrationDate: date,
          nextDueDate: calculatedNextDueDate,
          userId,
          status,
          nationalId: trimmedNatId || undefined,
          address: address.trim() || undefined,
          guarantorEnabled: guarantorEnabled || undefined,
          guarantorName: guarantorEnabled ? guarantorName.trim() || undefined : undefined,
          guarantorAddress: guarantorEnabled ? guarantorAddress.trim() || undefined : undefined,
          guarantorJob: guarantorEnabled ? guarantorJob.trim() || undefined : undefined,
          guarantorRelation: guarantorEnabled ? guarantorRelation.trim() || undefined : undefined,
          guarantorPhone: guarantorEnabled ? trimmedGPhone || undefined : undefined,
          notes: notes.trim() || undefined,
          payments: initialPayments,
          createdAt: fullDateTime,
          invoiceImage,
        });
      }

      resetForm();
      onClose();
    } catch (err: any) {
      setError(err?.message || t('common.errorOccurred', 'حدث خطأ أثناء الحفظ'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="unifiedAddModal"
      className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex justify-center items-end sm:items-center z-50 p-0 sm:p-4 animate-in fade-in duration-150 text-start"
    >
      <div className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-lg p-5 pb-28 sm:p-6 shadow-2xl relative border border-slate-100 max-h-[92vh] overflow-y-auto">
        {/* Top Header */}
        <div className="flex justify-between items-center mb-4 pb-3 border-b border-slate-100">
          <div className="font-extrabold text-base text-slate-800 flex items-center gap-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs ${
              entryType === 'debt'
                ? isUsd
                  ? 'bg-emerald-50 text-emerald-600'
                  : 'bg-blue-50 text-blue-600'
                : isUsd
                ? 'bg-cyan-50 text-cyan-600'
                : 'bg-emerald-50 text-emerald-600'
            }`}>
              <i className={`fa-solid ${entryType === 'debt' ? 'fa-user-plus' : 'fa-file-invoice-dollar'}`}></i>
            </div>
            <span>{entryType === 'debt' ? t('debtors.addDebtor', 'إضافة مدين جديد') : t('installments.addInstallment', 'تسجيل معاملة قسط جديدة')}</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 sm:w-9 sm:h-9 rounded-full bg-slate-100 hover:bg-slate-200 active:bg-slate-300 active:scale-95 flex items-center justify-center text-slate-500 hover:text-slate-800 transition-all cursor-pointer touch-manipulation shadow-2xs"
            title="خروج / إغلاق"
            aria-label="إغلاق النافذة"
          >
            <i className="fa-solid fa-xmark text-base"></i>
          </button>
        </div>

        {/* Segmented Switcher */}
        <div className="mb-4 bg-slate-100 p-1 rounded-2xl grid grid-cols-2 gap-1 select-none">
          <button
            type="button"
            onClick={() => {
              setEntryType('debt');
              setError(null);
            }}
            className={`py-2 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              entryType === 'debt'
                ? isUsd
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <i className="fa-solid fa-hand-holding-dollar text-xs"></i>
            <span>{t('common.regularDebt', 'دين عادي')}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setEntryType('installment');
              setError(null);
            }}
            className={`py-2 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              entryType === 'installment'
                ? isUsd
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/20'
                  : 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <i className="fa-solid fa-clock-rotate-left text-xs"></i>
            <span>{t('common.installments', 'أقساط شهرية')}</span>
          </button>
        </div>

        {error && (
          <div className="mb-4 p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-xl flex items-center gap-2">
            <i className="fa-solid fa-circle-exclamation shrink-0"></i>
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-3.5">
          {/* 1. Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {entryType === 'debt' ? t('debts.debtorName', 'اسم المدين') : t('installments.debtorName', 'اسم صاحب الأقساط')} <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              className={`w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl text-sm outline-none text-slate-800 transition-all ${
                entryType === 'debt'
                  ? 'border-slate-200 focus:border-blue-600 focus:bg-white focus:ring-2 focus:ring-blue-500/10'
                  : 'border-slate-200 focus:border-emerald-600 focus:bg-white focus:ring-2 focus:ring-emerald-500/10'
              }`}
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError(null);
              }}
              onFocus={handleInputFocus}
            />
            <NameDuplicateAlert
              checkResult={nameCheckResult}
              currency={currency}
              onSelectExisting={(rec) => {
                if (entryType === 'debt') {
                  const found = (existingDebtors || []).find((d) => d.id === rec.id);
                  if (found && onSelectExistingDebtor) onSelectExistingDebtor(found);
                } else {
                  const found = (existingInstallments || []).find((i) => i.id === rec.id);
                  if (found && onSelectExistingInstallment) onSelectExistingInstallment(found);
                }
              }}
              allowSameNameAnyway={allowDuplicateName}
              onToggleAllowSameName={setAllowDuplicateName}
            />
          </div>

          {/* 2. Phone */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t('debts.phoneNumber', 'رقم الهاتف')}
            </label>
            <div>
              <input
                type="tel"
                dir="ltr"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none text-slate-800 transition-all font-mono"
                maxLength={11}
                value={phone}
                onChange={handlePhoneChange}
                onFocus={handleInputFocus}
              />
            </div>
          </div>

          {/* DYNAMIC: DEBT VS INSTALLMENT FIELDS */}
          {entryType === 'debt' ? (
            /* DEBT FIELDS */
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center justify-between gap-1.5 flex-wrap">
                <span>{t('debts.initialDebtAmount', 'مبلغ الدين الأولي')} <span className="text-rose-500">*</span></span>
                <span className={`text-[11px] font-extrabold px-2 py-0.5 rounded-lg border ${
                  isUsd
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-blue-50 text-blue-700 border-blue-200'
                }`}>
                  {getArabicCurrencyLabel(currency)}
                </span>
              </label>
              <div className="relative flex items-center">
                <input
                  type="text"
                  dir="ltr"
                  inputMode="numeric"
                  placeholder="0"
                  className="w-full pl-14 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:border-blue-600 focus:bg-white text-slate-800 transition-all font-bold font-mono"
                  value={debtAmountStr}
                  onChange={(e) => setDebtAmountStr(formatAmountInput(e.target.value))}
                />
                <span className={`absolute left-3 text-xs font-extrabold pointer-events-none ${
                  isUsd ? 'text-emerald-700' : 'text-blue-700'
                }`}>
                  {isUsd ? 'دولار $' : 'دينار د.ع'}
                </span>
              </div>
              {parseFormattedNumber(debtAmountStr) > 0 && (
                <div className={`text-[11px] font-bold px-2.5 py-1.5 rounded-xl border flex items-center gap-1.5 ${
                  isUsd
                    ? 'bg-emerald-50/70 text-emerald-800 border-emerald-200/70'
                    : 'bg-blue-50/70 text-blue-800 border-blue-200/70'
                }`}>
                  <i className="fa-solid fa-spell-check text-[10px] opacity-75"></i>
                  <span>كتابةً: {formatAmountInArabicWords(debtAmountStr, currency)}</span>
                </div>
              )}
            </div>
          ) : (
            /* INSTALLMENT FIELDS */
            <>
              {/* 3. Item Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('installments.itemName', 'اسم السلعة / الغرض المقسط')} <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:border-emerald-600 focus:bg-white text-slate-800 transition-all"
                  value={item}
                  onChange={(e) => {
                    setItem(e.target.value);
                    if (error) setError(null);
                  }}
                />
              </div>

              {/* 4. Total Installment Amount & Down Payment */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 flex items-center justify-between gap-1">
                    <span>{t('installments.totalAmount', 'مبلغ الأقساط الكلي')} <span className="text-rose-500">*</span></span>
                    <span className={`text-[10.5px] font-extrabold px-1.5 py-0.5 rounded-md border ${
                      isUsd ? 'bg-cyan-50 text-cyan-700 border-cyan-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    }`}>
                      {getArabicCurrencyShort(currency)}
                    </span>
                  </label>
                  <div className="relative flex items-center">
                    <input
                      type="text"
                      dir="ltr"
                      inputMode="numeric"
                      placeholder="0"
                      required
                      value={totalInstallmentAmountStr}
                      onChange={(e) => setTotalInstallmentAmountStr(formatAmountInput(e.target.value))}
                      className="w-full pl-12 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black font-mono focus:border-emerald-600 focus:bg-white outline-none"
                    />
                    <span className={`absolute left-2.5 text-[11px] font-extrabold pointer-events-none ${
                      isUsd ? 'text-cyan-700' : 'text-emerald-700'
                    }`}>
                      {isUsd ? '$' : 'د.ع'}
                    </span>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 flex items-center justify-between gap-1">
                    <span>{t('installments.downPayment', 'الدفعة المقدمة')}</span>
                    <span className={`text-[10.5px] font-extrabold px-1.5 py-0.5 rounded-md border ${
                      isUsd ? 'bg-cyan-50 text-cyan-700 border-cyan-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    }`}>
                      {getArabicCurrencyShort(currency)}
                    </span>
                  </label>
                  <div className="relative flex items-center">
                    <input
                      type="text"
                      dir="ltr"
                      inputMode="numeric"
                      placeholder="0"
                      value={downPaymentStr}
                      onChange={(e) => setDownPaymentStr(formatAmountInput(e.target.value))}
                      className="w-full pl-12 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black font-mono focus:border-emerald-600 focus:bg-white outline-none"
                    />
                    <span className={`absolute left-2.5 text-[11px] font-extrabold pointer-events-none ${
                      isUsd ? 'text-cyan-700' : 'text-emerald-700'
                    }`}>
                      {isUsd ? '$' : 'د.ع'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Installment Summary Badge */}
              {parsedTotalInst > 0 && (
                <div className={`p-3 rounded-2xl border space-y-1.5 text-xs ${
                  isUsd ? 'bg-cyan-50/70 border-cyan-200/80' : 'bg-emerald-50/70 border-emerald-200/80'
                }`}>
                  <div className="flex items-center justify-between font-bold text-slate-900">
                    <span>{t('installments.remainingToPay', 'المتبقي المطلوب تقسيطه')}:</span>
                    <span className={`font-mono text-sm font-black ${isUsd ? 'text-cyan-700' : 'text-emerald-700'}`}>
                      {formatNumber(calculatedRemaining)} {isUsd ? 'دولار ($)' : 'دينار (د.ع)'}
                    </span>
                  </div>
                  <div className={`text-[11px] font-bold flex items-center gap-1.5 ${isUsd ? 'text-cyan-800' : 'text-emerald-800'}`}>
                    <i className="fa-solid fa-spell-check text-[10px] opacity-75"></i>
                    <span>كتابةً: {formatAmountInArabicWords(calculatedRemaining > 0 ? calculatedRemaining : parsedTotalInst, currency)}</span>
                  </div>
                  <div className={`flex items-center justify-between text-[11px] pt-1 border-t ${
                    isUsd ? 'text-cyan-800 border-cyan-200/60' : 'text-emerald-800 border-emerald-200/60'
                  }`}>
                    <span>{t('installments.firstDueDate', 'تاريخ الاستحقاق الأول (بعد شهر)')}:</span>
                    <span className={`font-mono font-bold bg-white px-2 py-0.5 rounded-lg border ${
                      isUsd ? 'border-cyan-200' : 'border-emerald-200'
                    }`}>
                      {calculatedNextDueDate}
                    </span>
                  </div>
                </div>
              )}

              {/* البطاقة الوطنية */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('installments.nationalId', 'رقم البطاقة الوطنية')}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    dir="ltr"
                    inputMode="numeric"
                    maxLength={12}
                    value={nationalId}
                    onChange={handleNationalIdChange}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold outline-none focus:border-emerald-600 focus:bg-white text-slate-800 transition-all"
                  />
                  <div className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs">
                    <i className="fa-solid fa-id-card"></i>
                  </div>
                </div>
              </div>

              {/* عنوان السكن وأقرب نقطة دالة */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('installments.address', 'عنوان السكن وأقرب نقطة دالة')}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 focus:bg-white text-slate-800 transition-all"
                  />
                  <div className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs">
                    <i className="fa-solid fa-location-dot"></i>
                  </div>
                </div>
              </div>

              {/* قائمة بيانات الكفيل */}
              <div className="border border-slate-200 rounded-2xl p-3 bg-slate-50/70 space-y-3">
                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={guarantorEnabled}
                    onChange={(e) => setGuarantorEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer accent-emerald-600"
                  />
                  <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                    <i className="fa-solid fa-user-shield text-emerald-600"></i>
                    <span>{t('installments.guarantorInfo', 'بيانات الكفيل')}</span>
                  </span>
                </label>

                {guarantorEnabled && (
                  <div className="pt-2 border-t border-slate-200/80 space-y-2.5 animate-in fade-in duration-150">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        {t('installments.guarantorName', 'اسم الكفيل')}
                      </label>
                      <input
                        type="text"
                        value={guarantorName}
                        onChange={(e) => setGuarantorName(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          {t('installments.guarantorRelation', 'صلة القرابة')}
                        </label>
                        <input
                          type="text"
                          value={guarantorRelation}
                          onChange={(e) => setGuarantorRelation(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          {t('installments.guarantorJob', 'مهنة الكفيل')}
                        </label>
                        <input
                          type="text"
                          value={guarantorJob}
                          onChange={(e) => setGuarantorJob(e.target.value)}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        {t('installments.guarantorAddress', 'عنوان الكفيل')}
                      </label>
                      <input
                        type="text"
                        value={guarantorAddress}
                        onChange={(e) => setGuarantorAddress(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        {t('installments.guarantorPhone', 'رقم هاتف الكفيل')}
                      </label>
                      <input
                        type="tel"
                        dir="ltr"
                        maxLength={11}
                        value={guarantorPhone}
                        onChange={handleGuarantorPhoneChange}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono outline-none focus:border-emerald-600 text-slate-800"
                      />
                    </div>
                  </div>
                )}
              </div>
            </>
          )}

          {/* Date Field */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t('common.date', 'تاريخ التسجيل')} {entryType === 'installment' ? `(${t('installments.setsMonthlyDueDate', 'يحدد الاستحقاق')})` : ''}
            </label>
            <input
              type="date"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm outline-none text-slate-800 transition-all font-mono"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>

          {/* Record Time Selector */}
          <RecordTimeSelector
            enabled={recordTime}
            onEnabledChange={setRecordTime}
            mode={timeMode}
            onModeChange={setTimeMode}
            time={time}
            onTimeChange={setTime}
            accentColor="emerald"
            idPrefix="unified_add"
          />

          {/* Notes Field */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t('common.notes', 'ملاحظات')} <span className="text-slate-400 font-normal">({t('common.optional', 'اختياري')})</span>
            </label>
            <input
              type="text"
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none text-slate-800 transition-all"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              maxLength={250}
            />
          </div>

          {/* Invoice Attachment Field */}
          <InvoiceAttachmentField
            value={invoiceImage}
            onChange={setInvoiceImage}
            allowUpload={allowInvoiceUpload}
            label={entryType === 'debt' ? 'صورة فاتورة / وصل الدين (اختياري)' : 'صورة عقد / فاتورة القسط (اختياري)'}
          />

          {/* Action Buttons */}
          <div className="flex gap-2.5 mt-3 pt-3 border-t border-slate-100 pb-[max(0.75rem,calc(env(safe-area-inset-bottom)+0.5rem))]">
            <button
              type="submit"
              disabled={isSubmitting}
              className={`flex-1 min-h-[48px] text-white py-3 rounded-xl font-bold text-sm shadow-md active:scale-[0.98] cursor-pointer transition-all flex items-center justify-center gap-2 disabled:opacity-50 touch-manipulation ${
                entryType === 'debt'
                  ? isUsd
                    ? 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 shadow-emerald-500/20'
                    : 'bg-blue-600 hover:bg-blue-700 active:bg-blue-800 shadow-blue-500/20'
                  : isUsd
                  ? 'bg-cyan-600 hover:bg-cyan-700 active:bg-cyan-800 shadow-cyan-500/20'
                  : 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 shadow-emerald-500/20'
              }`}
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>{t('common.saving', 'جاري الحفظ...')}</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-check text-xs"></i>
                  <span>{entryType === 'debt' ? t('debtors.saveDebtor', 'حفظ المدين') : t('installments.saveInstallment', 'حفظ وتسجيل القسط')}</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="flex-1 min-h-[48px] bg-slate-100 hover:bg-slate-200 active:bg-slate-300 active:scale-[0.98] text-slate-700 py-3 rounded-xl font-bold text-sm cursor-pointer transition-all touch-manipulation border border-slate-200/50"
            >
              {t('common.cancel', 'إلغاء')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
